<?php
include("includes/dbconnection.php");
$select=$bdd->query("SELECT s.*, u.* FROM soiree s, utilisateurs u WHERE s.id_utilisateur=u.id_utilisateur ORDER BY id_soiree ASC");
?>
<div class="pagetitle">
            <h1>Soirée</h1>
            <nav>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.html">Accueil</a></li>
                  <li class="breadcrumb-item active">Soirée</li>
               </ol>
            </nav>
         </div>
<!-- table responsive -->

<div class="card-body">
    <h5 class="card-title">Soirée <span>| Disponible</span></h5>
    <div class=" float-end ">
        <a href="index.php?page=pages/events/add_event" class="btn btn-success">Add</a>
        
    </div>
    <br>
    <br>
    <table class="table table-borderless datatable">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nom Soirée</th>
            <th scope="col">Addresse</th>
            <th scope="col">Prix</th>
            <th scope="col">Utilisateur</th>
            <th scope="col">Date</th>
            <th scope="col">Whatsapp</th>
            <th scope="col" colspan="2">Action</th>
        </tr>
        </thead>
        <tbody>
            <?php
            while($dataselect=$select->fetch()){
            ?>
        <tr>
            <th scope="row"><a href="#"><?php echo $dataselect["id_soiree"]?></a></th>
            <td><?php echo $dataselect["nom_soiree"]?></td>
            <td><a href="#" class="text-primary"><?php echo $dataselect["addresse"]?></a></td>
            <td><?php echo $dataselect["prix"]?> fbu</td>
            <td><?php echo $dataselect["nom"]?></td>
            <td><?php echo $dataselect["date_heure"]?></td>
            <td><?php echo $dataselect["whatsapp"]?></td>
            <td><span class="badge bg-success"><a href="index.php?page=pages/events/update_event&id=<?php echo $dataselect["id_soiree"]?>">Modifier</a></span></td>
            <td><span class="badge bg-success"><a href="index.php?page=pages/events/index&supp=<?php echo $dataselect["id_soiree"]?>" onclick="return confirm('Voulez-vous vraiment supprimer?')">Supprimer</a></span></td>
        </tr>
        <?php
            }
        ?>
      
        </tbody>
    </table>
</div>
<a href="deletelink" onclick="return confirm('Are you sure?')">Delete</a>

<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure?');
}
</script>

<?php
if(isset($_GET["supp"])){
    $idtodelete=$_GET["supp"];
    $delete=$bdd->EXEC("DELETE FROM soiree WHERE id_soiree=$idtodelete");
}
?>